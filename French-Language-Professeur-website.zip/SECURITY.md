# Security Policy

## Supported deployment

This project is a static browser application intended for GitHub Pages. Do not commit API keys, passwords, tokens, learner records, or other secrets to the repository.

## Reporting a vulnerability

Please do not report exploitable vulnerabilities in a public issue. Use GitHub's **Private vulnerability reporting** or a private Security Advisory for this repository if that feature is enabled. If private reporting is unavailable, contact the repository owner through a private channel listed on their GitHub profile. Include the affected URL/file, impact, and safe reproduction steps. Do not include real learner data or secrets.

## Security notes

- The optional Anthropic integration is a bring-your-own-key browser feature. A key entered by a learner is sent from their browser to Anthropic. Never add a shared project key to this static site.
- Browser local storage is not encrypted and is accessible to scripts running in the same origin and to anyone with access to the browser profile/device.
- Keep GitHub Pages deployment permissions restricted to the repository's GitHub Actions workflow.
- Review dependency and workflow changes before merging. This project currently aims to avoid runtime package dependencies.
- A Content Security Policy is included as a meta policy. Some response-header protections cannot be set by a meta tag on GitHub Pages; do not assume this file replaces hosting-level security controls.

## Response

The maintainer will review reports, validate impact, and coordinate a fix and disclosure where practical.
