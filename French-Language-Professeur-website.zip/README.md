# French Language Professeur

A standalone French self-study app with CEFR/IB lessons, quizzes, conversation practice, glossary, notes, conjugation, writing exercises, and a shared learning-resources page.

## Repository owner and administrator

The GitHub account that creates/owns this repository is its administrator. Use that account to manage repository settings, collaborators, site publication, and uploaded learning materials. The website itself deliberately has no client-side admin password: a password embedded in a static HTML site would be visible to every visitor and would not provide real security.

To give another person publishing access, open **Settings → Collaborators and teams** and grant the minimum role they need. Do not share your GitHub password or personal access token.

## Publish with GitHub Pages

1. Create a **public** GitHub repository named `french-language-professeur` under your account.
2. Upload the contents of this folder to the repository root (including `index.html`, policy pages, `materials/`, and `.github/workflows/pages.yml`).
3. In **Settings → Pages**, select **GitHub Actions** as the build/deployment source if needed.
4. The included workflow deploys the site after each push to the default branch.
5. The public URL will be `https://YOUR-GITHUB-USERNAME.github.io/french-language-professeur/`.

## Add more information and documents

See [materials/README.md](materials/README.md). Upload files into `materials/`, then add a visible link and description in [resources.html](resources.html). The Resources link in the app footer takes learners to the shared library.

**Important:** A public repository is public to everyone. Do not upload student records, private learner data, passwords, API keys, confidential school documents, or copyrighted materials without permission.

## Policies and security

Read [Privacy Notice](privacy.html), [Terms](terms.html), [Acceptable Use](acceptable-use.html), [Accessibility](accessibility.html), and [Security Policy](SECURITY.md).

This is a static site. Learner notes and progress are stored in the browser's local storage. The optional AI tutor requires each learner to provide their own Anthropic API key; never embed a shared API key in this repository. A shared AI tutor would require a separate server-side API with authentication, rate limits, abuse controls, and secret storage.

## Local testing

Open `index.html` in a modern browser or serve this directory with a local static web server. Speech features vary by browser.
